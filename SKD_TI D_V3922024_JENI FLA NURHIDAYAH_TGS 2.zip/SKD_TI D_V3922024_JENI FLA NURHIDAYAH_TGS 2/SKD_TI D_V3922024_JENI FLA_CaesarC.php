<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Sistem Keamanan Data</title>
</head>

<body>
    <div class="container">
        <div class="judul">
            <h3>Enkripsi dan Dekripsi</h3>
            <h5>Caesar Chiper</h5>
        </div>
        <div class="card card-outline card-primary">
            <div class="card-body">
            <?php
                // Memeriksa apakah tombol "enkripsi" atau "dekripsi" telah ditekan
                if (isset($_POST['enkripsi']) || isset($_POST['dekripsi'])) {

                // Fungsi enkripsi dengan kunci pergeseran 22
                function enkripsi($input)
                {
                    $output = ""; // Variabel untuk menyimpan hasil enkripsi
                    $chars = str_split($input); // Memisahkan teks input menjadi karakter-karakter individu

                    foreach ($chars as $char) { // Memulai loop untuk setiap karakter dalam teks input
                        if (ctype_alpha($char)) { // Memeriksa apakah karakter adalah huruf (alphabet)
                            $is_upper = ctype_upper($char); // Memeriksa apakah huruf tersebut kapital atau tidak
                            $offset = $is_upper ? ord('A') : ord('a'); // Menentukan offset sesuai dengan huruf besar atau kecil
                            $encrypted_char = chr((($is_upper ? ord($char) : ord($char)) + 22 - $offset + 26) % 26 + $offset);
                            // Menerapkan rumus enkripsi Caesar dengan pergeseran 22
                            // Menggunakan ord() untuk mendapatkan nilai ASCII karakter
                            // Menambahkan 22 ke nilai ASCII dan menghindari nilai yang di luar jangkauan (dengan mod 26)
                            // Mengonversi kembali ke karakter dengan chr() dan menambahkan offset kembali
                            
                            $output .= $encrypted_char; // Menambahkan karakter yang sudah dienkripsi ke hasil keluaran
                        } else {
                            $output .= $char; // Jika karakter bukan huruf, langsung tambahkan ke hasil keluaran
                        }
                    }

                    return $output; // Mengembalikan hasil teks yang sudah dienkripsi
                }

                // Fungsi dekripsi dengan kunci pergeseran 22
                function dekripsi($input)
                {
                    $output = ""; // Variabel untuk menyimpan hasil dekripsi
                    $chars = str_split($input); // Memisahkan teks input menjadi karakter-karakter individu

                    foreach ($chars as $char) { // Memulai loop untuk setiap karakter dalam teks input
                        if (ctype_alpha($char)) { // Memeriksa apakah karakter adalah huruf (alphabet)
                            $is_upper = ctype_upper($char); // Memeriksa apakah huruf tersebut kapital atau tidak
                            $offset = $is_upper ? ord('A') : ord('a'); // Menentukan offset sesuai dengan huruf besar atau kecil
                            $decrypted_char = chr((($is_upper ? ord($char) : ord($char)) - 22 - $offset + 26) % 26 + $offset);
                            // Menerapkan rumus dekripsi Caesar dengan pergeseran 22
                            // Menggunakan ord() untuk mendapatkan nilai ASCII karakter
                            // Mengurangkan 22 dari nilai ASCII dan menghindari nilai yang di luar jangkauan (dengan mod 26)
                            // Mengonversi kembali ke karakter dengan chr() dan menambahkan offset kembali
                            
                            $output .= $decrypted_char; // Menambahkan karakter yang sudah didekripsi ke hasil keluaran
                        } else {
                            $output .= $char; // Jika karakter bukan huruf, langsung tambahkan ke hasil keluaran
                        }
                    }

                    return $output; // Mengembalikan hasil teks yang sudah didekripsi
                }
                }
                ?>


                <!-- Form  -->
                <form name="skd" method="post">
                    <!-- Label inputan -->
                    <div class="label">
                        <p>Masukan Text </p>
                    </div>
                    <!-- Form input text -->
                    <div class="input-group mb-3">
                        <input type="text" name="plain" class="form-control">
                    </div>
                    <div class="box-footer">
                        <table class="table table-stripped">
                            <tr>
                                <!-- button enkripsi dan dekripsi -->
                                <td><input class="btn" type="submit" name="enkripsi" value="Enkripsi" style="width: 100%"></td>
                                <td><input class="btn" type="submit" name="dekripsi" value="Dekripsi" style="width: 100%"></td>
                            </tr>
                        </table>
                    </div>
                </form>
            </div>
        </div>
            <!-- Hasil enkripsi/dekripsi -->
            <div class="output">
                
            </div>
            <div class="card card-outline card-primary">
            <div class="card-output">
            <h4>Output</h4>
                <table>
                    <!-- Menampilkan hasil output dari enkripsi/dekripsi -->
                    <tr>
                        <td> Output yang dihasilkan : </td>
                        <td><b>
                                <?php if (isset($_POST['enkripsi'])) { 
                                    echo enkripsi($_POST['plain']); //memanggil fungsi enkripsi dan menampilkannya
                                }
                                if (isset($_POST['dekripsi'])) { 
                                    echo dekripsi($_POST['plain']); //memanggil fungsi dekripsi dan menampilkannya
                                } ?></b></td>
                    </tr>
                    <tr>
                        <!-- menampilkan text yang dimasukkan -->
                        <td>Text yang dimasukkan : </td>
                        <td><b>
                                <?php if (isset($_POST['enkripsi'])) { 
                                    echo dekripsi(enkripsi($_POST['plain'])); //memanggil fungsi dekripsi yang sebelumnya dienkripsi dan menampilkannya
                                }
                                if (isset($_POST['dekripsi'])) { 
                                    echo enkripsi(dekripsi($_POST['plain'])); //memanggil fungsi enkripsi yang sebelumnya didekripsi dan menampilkannya
                                } ?></b></td>
                    </tr>
                </table>
            </div>
            </div>
        </div>
    </div>
    </form>

    <script>
        $(function() {
            $('.select2').select2()

        })
    </script>
</body>

</html>
<style>
    

    /* CSS untuk mengatur tampilan elemen-elemen */
.container {
    width: 40%;
    margin: 87px auto;
}

.judul {
    text-align: center;
}

.card-body {
    background-color: #CEDEBD;
    padding: 20px; 
}

.label p{
    font-size: 18px;
}

.input-group {
    margin-bottom: 10px; /* Jarak bawah antara input teks dan tombol */
}

.btn {
    background-color: #435334;
    color: white; /* Warna teks tombol */
    border: none;
    width: 100%;
}

.output {
 /* Warna latar belakang kotak output */
    padding: 10px;
    margin-top: 40px; /* Jarak atas dari kotak output ke elemen sebelumnya */
}

.card-output{
    background-color: #9EB384;
    padding: 20px;
}
</style>
